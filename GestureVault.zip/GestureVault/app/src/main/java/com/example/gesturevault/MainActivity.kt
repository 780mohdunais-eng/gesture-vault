package com.example.gesturevault

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var gestureLibrary: GestureLibrary
    private lateinit var adapter: AppAdapter
    private var iconHidden = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Same private file used everywhere so all components share one gesture set
        gestureLibrary = GestureLibraries.fromPrivateFile(this, "gestures")
        gestureLibrary.load()

        val apps = loadLaunchableApps()

        val recycler = findViewById<RecyclerView>(R.id.appList)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = AppAdapter(apps, gestureLibrary) { app ->
            val intent = Intent(this, RecordGestureActivity::class.java)
            intent.putExtra("package_name", app.packageName)
            intent.putExtra("app_label", app.label)
            startActivity(intent)
        }
        recycler.adapter = adapter

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            requestOverlayPermission()
        }

        findViewById<Button>(R.id.btnToggleService).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Pehle overlay permission do", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
            } else {
                startService(Intent(this, TriggerService::class.java))
                Toast.makeText(this, "Left edge pe thin line lagi hogi — usko andar kheecho", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnHideIcon).setOnClickListener {
            toggleIcon()
        }
    }

    override fun onResume() {
        super.onResume()
        // Picks up gestures recorded in RecordGestureActivity since last load
        gestureLibrary.load()
        adapter.notifyDataSetChanged()
    }

    private fun loadLaunchableApps(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolveInfos
            .filter { it.activityInfo.packageName != packageName }
            .map {
                InstalledApp(
                    packageName = it.activityInfo.packageName,
                    label = it.loadLabel(pm).toString(),
                    icon = it.loadIcon(pm)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            Toast.makeText(this, "Overlay permission already diya hua hai", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleIcon() {
        val alias = ComponentName(this, "com.example.gesturevault.MainActivityLauncher")
        iconHidden = !iconHidden
        val newState = if (iconHidden)
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        else
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED

        packageManager.setComponentEnabledSetting(alias, newState, PackageManager.DONT_KILL_APP)

        val msg = if (iconHidden)
            "Icon hide ho gaya. Wapas kholne ke liye bubble ya adb use karo."
        else
            "Icon wapas dikhne lagega."
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}

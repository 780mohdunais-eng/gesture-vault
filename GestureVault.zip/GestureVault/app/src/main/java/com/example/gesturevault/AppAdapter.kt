package com.example.gesturevault

import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val apps: List<InstalledApp>,
    private val gestureLibrary: GestureLibrary,
    private val onRecordClick: (InstalledApp) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val name: TextView = view.findViewById(R.id.appName)
        val status: TextView = view.findViewById(R.id.appStatus)
        val recordBtn: Button = view.findViewById(R.id.btnRecord)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.name.text = app.label

        val gestureCount = gestureLibrary.getGestures(app.packageName)?.size ?: 0
        holder.status.text = if (gestureCount > 0) "$gestureCount gesture(s) saved" else "no gesture yet"

        holder.recordBtn.setOnClickListener { onRecordClick(app) }
    }

    override fun getItemCount() = apps.size
}

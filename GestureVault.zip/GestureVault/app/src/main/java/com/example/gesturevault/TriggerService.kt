package com.example.gesturevault

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.gesture.Gesture
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.GestureOverlayView
import android.gesture.Prediction
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat

class TriggerService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var gestureLibrary: GestureLibrary

    private var bubbleView: View? = null
    private var gestureOverlayContainer: View? = null

    private val channelId = "gesture_vault_trigger"
    private val notifId = 1001

    // Minimum score for android.gesture Prediction to be treated as a confident match
    private val matchThreshold = 2.2

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        gestureLibrary = GestureLibraries.fromPrivateFile(this, "gestures")
        gestureLibrary.load()

        startForeground(notifId, buildNotification())
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        gestureOverlayContainer?.let { runCatching { windowManager.removeView(it) } }
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, TriggerService::class.java).apply { action = "STOP" }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_secure)
            .setOngoing(true)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    // ---------- Floating bubble ----------

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 300

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var isDrag = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    isDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) isDrag = true
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    windowManager.updateViewLayout(v, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDrag) showGestureOverlay()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
    }

    // ---------- Full-screen gesture capture ----------

    private fun showGestureOverlay() {
        if (gestureOverlayContainer != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_gesture, null)
        gestureOverlayContainer = view

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            0, // focusable, touchable - captures the gesture
            PixelFormat.TRANSLUCENT
        )

        val overlayGestureView = view.findViewById<GestureOverlayView>(R.id.fullGestureOverlay)
        overlayGestureView.addOnGesturePerformedListener { _: GestureOverlayView, gesture: Gesture ->
            handleGesture(gesture)
        }

        windowManager.addView(view, params)
    }

    private fun removeGestureOverlay() {
        gestureOverlayContainer?.let {
            runCatching { windowManager.removeView(it) }
        }
        gestureOverlayContainer = null
    }

    private fun handleGesture(gesture: Gesture) {
        gestureLibrary.load() // pick up any newly recorded gestures
        val predictions: ArrayList<Prediction> = gestureLibrary.recognize(gesture)
        predictions.sortByDescending { it.score }

        val best = predictions.firstOrNull()
        if (best != null && best.score >= matchThreshold) {
            launchApp(best.name)
        } else {
            Toast.makeText(this, "Sign pehchana nahi gaya", Toast.LENGTH_SHORT).show()
        }
        removeGestureOverlay()
    }

    private fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "App nahi mila (uninstall ho gaya shayad)", Toast.LENGTH_SHORT).show()
        }
    }
}

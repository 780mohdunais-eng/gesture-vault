package com.example.gesturevault

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.gesture.Gesture
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.Prediction
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class TriggerService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var gestureLibrary: GestureLibrary
    private lateinit var edgeView: EdgeGestureView
    private lateinit var params: WindowManager.LayoutParams

    private val channelId = "gesture_vault_trigger"
    private val notifId = 1001

    // Minimum score for android.gesture Prediction to be treated as a confident match
    private val matchThreshold = 2.2

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        gestureLibrary = GestureLibraries.fromPrivateFile(this, "gestures")
        gestureLibrary.load()

        startForeground(notifId, buildNotification())
        addEdgeView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (::edgeView.isInitialized) {
            runCatching { windowManager.removeView(edgeView) }
        }
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, TriggerService::class.java).apply { action = "STOP" }
        val stopPending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Left edge se andar swipe karke gesture banao — tap karke app kholo")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    // ---------- Edge handle + full-screen capture, same window resized in place ----------

    private fun addEdgeView() {
        edgeView = EdgeGestureView(this)

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            dp(38), dp(220),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = -1 // centered vertically via CENTER_VERTICAL below
        params.gravity = Gravity.START or Gravity.CENTER_VERTICAL

        edgeView.onExpand = {
            vibrate()
            collapseOrExpand(expand = true)
        }
        edgeView.onCollapse = {
            collapseOrExpand(expand = false)
        }
        edgeView.onGesture = { gesture -> handleGesture(gesture) }

        windowManager.addView(edgeView, params)
    }

    private fun collapseOrExpand(expand: Boolean) {
        if (expand) {
            params.width = WindowManager.LayoutParams.MATCH_PARENT
            params.height = WindowManager.LayoutParams.MATCH_PARENT
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 0
            params.y = 0
        } else {
            params.width = dp(38)
            params.height = dp(220)
            params.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            params.x = 0
            params.y = 0
        }
        runCatching { windowManager.updateViewLayout(edgeView, params) }
    }

    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------- Recognition ----------

    private fun handleGesture(gesture: Gesture) {
        try {
            gestureLibrary.load() // pick up any newly recorded gestures
            val predictions: ArrayList<Prediction> = gestureLibrary.recognize(gesture)
            predictions.sortByDescending { it.score }
            val best = predictions.firstOrNull()
            if (best != null && best.score >= matchThreshold) {
                launchApp(best.name)
            }
            // no match -> stay silent, view already collapsed itself via onCollapse
        } catch (e: Exception) {
            // swallow - view already returns to idle edge state regardless
        }
    }

    private fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)
    }
}

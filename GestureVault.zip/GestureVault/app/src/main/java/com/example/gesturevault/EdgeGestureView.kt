package com.example.gesturevault

import android.content.Context
import android.gesture.Gesture
import android.gesture.GesturePoint
import android.gesture.GestureStroke
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Idle state: draws a thin translucent pill at the left edge (just a visual hint).
 * Active state: once the user touches down on that edge, the whole view becomes a
 * full-screen transparent canvas, tracks the drag as a gesture stroke (drawn as a
 * soft glowing line), and hands the finished stroke back as an android.gesture.Gesture
 * when the finger lifts.
 */
class EdgeGestureView(context: Context) : View(context) {

    var onExpand: (() -> Unit)? = null
    var onCollapse: (() -> Unit)? = null
    var onGesture: ((Gesture) -> Unit)? = null

    private var active = false
    private val points = ArrayList<GesturePoint>()
    private val path = Path()
    private var lastX = 0f
    private var lastY = 0f

    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#59C9A15F")
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EAD09A")
        style = Paint.Style.STROKE
        strokeWidth = 9f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(14f, 0f, 0f, Color.parseColor("#AAC9A15F"))
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, strokePaint) // needed for shadowLayer glow to render
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!active) {
            val cy = height / 2f
            val r = RectF(0f, cy - 55f, 7f, cy + 55f)
            canvas.drawRoundRect(r, 6f, 6f, handlePaint)
        } else {
            canvas.drawPath(path, strokePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rx = event.rawX
        val ry = event.rawY

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (!active) {
                    active = true
                    points.clear()
                    path.reset()
                    points.add(GesturePoint(rx, ry, event.eventTime))
                    path.moveTo(rx, ry)
                    lastX = rx; lastY = ry
                    onExpand?.invoke()
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (active) {
                    points.add(GesturePoint(rx, ry, event.eventTime))
                    path.lineTo(rx, ry)
                    lastX = rx; lastY = ry
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (active) {
                    if (event.action == MotionEvent.ACTION_UP && points.size >= 6) {
                        val stroke = GestureStroke(points)
                        val gesture = Gesture()
                        gesture.addStroke(stroke)
                        onGesture?.invoke(gesture)
                    }
                    active = false
                    points.clear()
                    path.reset()
                    invalidate()
                    onCollapse?.invoke()
                }
                return true
            }
        }
        return false
    }
}

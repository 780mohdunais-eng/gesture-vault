package com.example.gesturevault

import android.content.Context
import android.gesture.Gesture
import android.gesture.GesturePoint
import android.gesture.GestureStroke
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Two-step interaction:
 *  1. IDLE  -> user touches the thin edge hint and drags inward past a threshold.
 *              Once crossed we go ARMED: vibrate + expand to full screen, transparent.
 *              Lifting the finger here does nothing except stay ARMED.
 *  2. ARMED -> a *fresh* touch-down anywhere on screen starts the real sign (DRAWING).
 *              On lifting that finger, the collected stroke is handed back as a Gesture.
 *              If nothing is drawn within a few seconds, it quietly collapses back to IDLE.
 */
class EdgeGestureView(context: Context) : View(context) {

    private enum class State { IDLE, PULLING, ARMED, DRAWING }

    var onExpand: (() -> Unit)? = null
    var onCollapse: (() -> Unit)? = null
    var onGesture: ((Gesture) -> Unit)? = null

    private var state = State.IDLE
    private var pullStartX = 0f
    private val activateThresholdPx = context.resources.displayMetrics.density * 28f
    private val armedTimeoutMs = 6000L

    private val points = ArrayList<GesturePoint>()
    private val path = Path()

    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#59C9A15F")
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EAD09A")
        style = Paint.Style.STROKE
        strokeWidth = 9f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(14f, 0f, 0f, Color.parseColor("#AAC9A15F"))
    }

    private var armedTimeoutRunnable: Runnable? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, strokePaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        when (state) {
            State.IDLE -> {
                val cy = height / 2f
                val r = RectF(0f, cy - 55f, 7f, cy + 55f)
                canvas.drawRoundRect(r, 6f, 6f, handlePaint)
            }
            State.DRAWING -> canvas.drawPath(path, strokePaint)
            else -> { /* PULLING / ARMED: fully transparent, vibration is the feedback */ }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rx = event.rawX
        val ry = event.rawY

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                when (state) {
                    State.IDLE -> {
                        state = State.PULLING
                        pullStartX = rx
                    }
                    State.ARMED -> {
                        cancelArmedTimeout()
                        state = State.DRAWING
                        points.clear()
                        path.reset()
                        points.add(GesturePoint(rx, ry, event.eventTime))
                        path.moveTo(rx, ry)
                        invalidate()
                    }
                    else -> {}
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (state) {
                    State.PULLING -> {
                        if (rx - pullStartX > activateThresholdPx) {
                            state = State.ARMED
                            onExpand?.invoke()
                            scheduleArmedTimeout()
                            invalidate()
                        }
                    }
                    State.DRAWING -> {
                        points.add(GesturePoint(rx, ry, event.eventTime))
                        path.lineTo(rx, ry)
                        invalidate()
                    }
                    else -> {}
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (state) {
                    State.PULLING -> {
                        // let go before crossing the threshold - nothing happened, stay idle
                        state = State.IDLE
                    }
                    State.ARMED -> {
                        // this was just the activation finger lifting - keep waiting, stay ARMED
                    }
                    State.DRAWING -> {
                        if (event.action == MotionEvent.ACTION_UP && points.size >= 6) {
                            val stroke = GestureStroke(points)
                            val gesture = Gesture()
                            gesture.addStroke(stroke)
                            onGesture?.invoke(gesture)
                        }
                        state = State.IDLE
                        points.clear()
                        path.reset()
                        onCollapse?.invoke()
                    }
                    else -> {}
                }
                invalidate()
                return true
            }
        }
        return false
    }

    private fun scheduleArmedTimeout() {
        cancelArmedTimeout()
        val r = Runnable {
            if (state == State.ARMED) {
                state = State.IDLE
                invalidate()
                onCollapse?.invoke()
            }
        }
        armedTimeoutRunnable = r
        postDelayed(r, armedTimeoutMs)
    }

    private fun cancelArmedTimeout() {
        armedTimeoutRunnable?.let { removeCallbacks(it) }
        armedTimeoutRunnable = null
    }
}

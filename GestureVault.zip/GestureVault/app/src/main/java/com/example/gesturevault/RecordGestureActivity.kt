package com.example.gesturevault

import android.gesture.Gesture
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.GestureOverlayView
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RecordGestureActivity : AppCompatActivity() {

    private lateinit var gestureLibrary: GestureLibrary
    private var savedCount = 0
    private lateinit var packageName_: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record_gesture)

        packageName_ = intent.getStringExtra("package_name") ?: ""
        val appLabel = intent.getStringExtra("app_label") ?: packageName_

        findViewById<TextView>(R.id.recordTitle).text = "\"$appLabel\" ke liye sign draw karo"

        gestureLibrary = GestureLibraries.fromPrivateFile(this, "gestures")
        gestureLibrary.load()
        savedCount = gestureLibrary.getGestures(packageName_)?.size ?: 0
        updateCount()

        val overlay = findViewById<GestureOverlayView>(R.id.gestureOverlay)
        overlay.addOnGesturePerformedListener { ov: GestureOverlayView, gesture: Gesture ->
            if (gesture.length < 15) {
                Toast.makeText(this, "Bahut chota tha, dobara try karo", Toast.LENGTH_SHORT).show()
            } else {
                gestureLibrary.addGesture(packageName_, gesture)
                val ok = gestureLibrary.save()
                savedCount++
                updateCount()
                Toast.makeText(this, "Saved ($savedCount) — saved=$ok", Toast.LENGTH_SHORT).show()
            }
            // fade is disabled now, so clear the canvas manually for the next draw
            ov.postDelayed({ ov.clear(false) }, 300)
        }

        findViewById<Button>(R.id.btnDoneRecording).setOnClickListener {
            if (savedCount == 0) {
                Toast.makeText(this, "Kam se kam ek baar draw karo", Toast.LENGTH_SHORT).show()
            } else {
                finish()
            }
        }
    }

    private fun updateCount() {
        findViewById<TextView>(R.id.recordCount).text = "$savedCount saved"
    }
}

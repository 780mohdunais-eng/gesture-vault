package com.example.gesturevault

import android.gesture.Gesture
import android.gesture.GestureLibraries
import android.gesture.GestureLibrary
import android.gesture.GestureOverlayView
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RecordGestureActivity : AppCompatActivity() {

    private lateinit var gestureLibrary: GestureLibrary
    private var savedCount = 0
    private lateinit var packageName_: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record_gesture)

        packageName_ = intent.getStringExtra("package_name") ?: ""
        val appLabel = intent.getStringExtra("app_label") ?: packageName_

        findViewById<TextView>(R.id.recordTitle).text = "\"$appLabel\" ke liye sign draw karo"

        gestureLibrary = GestureLibraries.fromPrivateFile(this, "gestures")
        gestureLibrary.load()
        savedCount = gestureLibrary.getGestures(packageName_)?.size ?: 0
        updateCount()

        val overlay = findViewById<GestureOverlayView>(R.id.gestureOverlay)
        overlay.addOnGesturePerformedListener { _: GestureOverlayView, gesture: Gesture ->
            if (gesture.length < 40) {
                Toast.makeText(this, "Bahut chota — thoda bada draw karo", Toast.LENGTH_SHORT).show()
                return@addOnGesturePerformedListener
            }
            gestureLibrary.addGesture(packageName_, gesture)
            gestureLibrary.save()
            savedCount++
            updateCount()
            Toast.makeText(this, "Saved ($savedCount)", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnDoneRecording).setOnClickListener {
            if (savedCount == 0) {
                Toast.makeText(this, "Kam se kam ek baar draw karo", Toast.LENGTH_SHORT).show()
            } else {
                finish()
            }
        }
    }

    private fun updateCount() {
        findViewById<TextView>(R.id.recordCount).text = "$savedCount saved"
    }
}
